// Variables to store user input information for the decision-making app

// Number variable - stores the price of the item the user wants to buy
var itemPrice = 0;

// Number variable - stores how much money the user has available to spend
var availableMoney = 0;

// String variable - stores whether the item is a "need" or "want"
var needLevel = "";

// This function determines whether the user should buy an item based on their budget and need level
// It takes the item price, available money, and need level to make a recommendation
// The function displays one of three possible outcomes on the screen
function updateScreen() {
    // Get values from the input elements on the screen
    itemPrice = getNumber("priceInput");
    availableMoney = getNumber("moneyInput"); 
    needLevel = getText("needDropdown");
    
    // Main decision logic using conditional statements with logical operators
    if (itemPrice <= availableMoney && needLevel == "Need (I NEED IT)" && availableMoney - itemPrice < 20) {
        // User can afford it AND it's a need BUT they'll have less than $20 left
        setText("resultText", "YES - Buy it now!");
        setText("explanationText", "You can afford it and though you will have less than $20 left, it's a need.");
        
    } else if (itemPrice <= availableMoney && (needLevel == "Need (I NEED IT)" || availableMoney - itemPrice >= 20)) {
        // User can afford it AND (it's a need OR they'll have $20+ left over)
        setText("resultText", "YES - Buy it now!");
        setText("explanationText", "You can afford it and it makes financial sense.");
        
    } else if (itemPrice <= availableMoney) {
        // User can afford it BUT it's a want AND would use most of their money
        setText("resultText", "MAYBE - Think about it more");
        setText("explanationText", "You can afford it but it might use too much of your money.");
        
    } else {
        // User cannot afford the item at all
        setText("resultText", "NO - Wait until you have more money");
        setText("explanationText", "You cannot afford this item right now.");
    }
}

// Event handler for when user clicks the main decision button
onEvent("buyButton", "click", function() {
    itemPrice = getNumber("priceInput");
    availableMoney = getNumber("moneyInput");
    needLevel = getText("needDropdown");
    updateScreen();
});

// Event handler for when user clicks start over button
onEvent("startOverButton", "click", function() {
    itemPrice = 0;
    availableMoney = 0;
    needLevel = "";
    setText("priceInput", "");
    setText("moneyInput", "");
    setText("needDropdown", "");
    setText("resultText", "");
    setText("explanationText", "");
});
